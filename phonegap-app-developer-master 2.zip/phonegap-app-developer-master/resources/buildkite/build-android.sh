#!/usr/bin/env bash
npm run -- release-android
